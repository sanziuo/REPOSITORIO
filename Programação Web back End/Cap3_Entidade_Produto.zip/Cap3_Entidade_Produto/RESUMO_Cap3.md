# Capítulo 3 — Modelando a Entidade Produto

## ORM (Mapeamento Objeto-Relacional)
| Java | Banco |
|---|---|
| Classe `Produto` | Tabela `PRODUTO` |
| Atributo `nome`, `preco` | Coluna `NOME`, `PRECO` |
| Objeto | Linha / registro |
| Atributo `id` | Chave primária |

| | JDBC puro | JPA/Hibernate |
|---|---|---|
| SQL | manual | gerado |
| Conversão | manual (ResultSet) | automática |
| Mudar estrutura | ajustar SQL em vários pontos | alterar a entidade |
| Trocar banco | reescrever SQL | trocar o dialeto |

## JPA × Hibernate
| JPA | Hibernate |
|---|---|
| Especificação (regras, anotações) | Implementação (framework) |
| Define **como** anotar | Gera e executa o SQL |
| A planta da casa | A construtora |

`javax.persistence` (antigo) = `jakarta.persistence` (atual, usado no livro).

## Pacotes
`model` (entidades) · `repository` (acesso ao banco) · `service` (regras) · `controller` (HTTP)

## Anotações
| Anotação | Onde | Para quê |
|---|---|---|
| @Entity | classe | vira tabela |
| @Id | atributo id | chave primária |
| @GeneratedValue(strategy = IDENTITY) | com @Id | auto incremento do banco |
| @Table (opcional) | classe | nome da tabela |
| @Column (opcional) | atributo | nome, nullable, length |

Estratégias: **IDENTITY** (auto incremento – usada no projeto) · **SEQUENCE** (PostgreSQL/Oracle) ·
**TABLE** (tabela auxiliar, lenta) · **AUTO** (Hibernate escolhe; padrão).

**POJO** = classe Java comum. **Construtor vazio é obrigatório** na entidade
(sem ele → `InstantiationException`).

## application.properties
| Propriedade | Papel |
|---|---|
| spring.datasource.url=jdbc:h2:mem:restaurantebd | H2 em memória (dados somem ao parar) |
| driverClassName / username=sa / password= | conexão |
| spring.h2.console.enabled / path=/h2-console | console web |
| spring.jpa.database-platform=H2Dialect | dialeto SQL |
| spring.jpa.hibernate.ddl-auto=update | cria/ajusta tabelas (produção: Flyway/Liquibase) |
| show-sql / format_sql | mostra o SQL no console |

## Verificação
1. Rodar `RestauranteApplication` → console mostra `create table produto (...)`.
2. http://localhost:8080/h2-console → JDBC URL **jdbc:h2:mem:restaurantebd** (o padrão vem `testdb`!), user `sa`, senha vazia.
3. `SELECT * FROM PRODUTO;` → tabela vazia (esperado).

| Problema | Causa |
|---|---|
| Tabela não aparece | Falta @Entity ou classe fora do pacote base |
| No identifier specified | Falta @Id |
| InstantiationException | Falta construtor vazio |
| SQL não aparece | `show-sql` digitado errado |
| Erro ao conectar | Aplicação parada ou JDBC URL diferente |

## Exercício de fixação (já resolvido no projeto)
Atributo `categoria` (String) com getter/setter adicionado ao `Produto`.
Rode a aplicação: o SQL passa a ter `categoria varchar(255)` e o `SELECT * FROM PRODUTO` mostra a coluna **CATEGORIA**.
