package br.com.suaempresa.restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// Teste básico: verifica se o container Spring sobe sem erros.
@SpringBootTest
class RestauranteApplicationTests {

	@Test
	void contextLoads() {
	}
}
