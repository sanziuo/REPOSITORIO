package br.com.suaempresa.restaurante.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/*
 * ENTIDADE JPA - ORM na prática:
 *   classe Produto  -> tabela PRODUTO
 *   atributos       -> colunas ID, NOME, PRECO, CATEGORIA
 *   cada objeto     -> uma linha da tabela
 */
@Entity // marca a classe como entidade: o Hibernate cria a tabela
public class Produto {

	@Id // chave primária
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto incremento do banco (H2/MySQL)
	private Long id;

	private String nome;   // coluna NOME   (sem anotação: mapeamento padrão)
	private Double preco;  // coluna PRECO

	// Exercício de fixação do Capítulo 3: nova coluna CATEGORIA
	private String categoria;

	// Construtor vazio OBRIGATÓRIO: o Hibernate instancia com ele e depois usa os setters.
	public Produto() {
	}

	// Construtor de conveniência (por isso o vazio precisou ser declarado acima).
	public Produto(String nome, Double preco, String categoria) {
		this.nome = nome;
		this.preco = preco;
		this.categoria = categoria;
	}

	// Getters e Setters (Alt+Insert -> Getter and Setter)
	public Long getId() { return id; }
	public void setId(Long id) { this.id = id; }

	public String getNome() { return nome; }
	public void setNome(String nome) { this.nome = nome; }

	public Double getPreco() { return preco; }
	public void setPreco(Double preco) { this.preco = preco; }

	public String getCategoria() { return categoria; }
	public void setCategoria(String categoria) { this.categoria = categoria; }
}
