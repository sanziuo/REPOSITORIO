package br.com.suaempresa.restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Classe principal. Ao rodar, o Hibernate lê a entidade Produto e,
 * com ddl-auto=update, cria a tabela PRODUTO no H2 (veja o SQL no console).
 * Depois acesse: http://localhost:8080/h2-console
 *   JDBC URL: jdbc:h2:mem:restaurantebd | User: sa | Password: (vazio)
 */
@SpringBootApplication
public class RestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestauranteApplication.class, args);
	}
}
