# Capítulo 2 — Estrutura Base do Projeto: Spring Boot e Maven

## Spring Framework
| Conceito | Significado |
|---|---|
| IoC (Inversão de Controle) | Quem cria os objetos é o **container**, não o seu código |
| Bean | Objeto criado e gerenciado pelo container |
| DI (Injeção de Dependência) | O Spring entrega o objeto pronto (`@Autowired` / construtor) |
| Component Scan | Varre o pacote procurando classes anotadas |

- Sem Spring: `new ProdutoRepository()` → acoplamento forte, difícil testar/trocar.
- Com Spring: `@Autowired private ProdutoRepository repository;` → baixo acoplamento.

| Anotação | Camada |
|---|---|
| @Component | genérica |
| @Service | regras de negócio |
| @Repository | banco de dados (traduz exceções) |
| @Controller / @RestController | web: HTML / JSON |

Todas registram Beans; o nome indica o papel. **`@Autowired` só funciona dentro de um Bean** (não no `main` estático).

## Spring Boot
- Camada **sobre** o Spring Framework (não o substitui).
- **Convenção sobre configuração**: auto-configura conforme o `pom.xml`.
- **Servidor embutido (Tomcat)**: roda com um comando.
- `@SpringBootApplication` = `@Configuration` + `@EnableAutoConfiguration` + `@ComponentScan`
  → todas as classes devem ficar **abaixo do pacote base**.

## Maven
Gerencia dependências (baixa os .jar para `.m2`) e automatiza o build. Arquivo: **pom.xml**
(`groupId` = fornecedor, `artifactId` = nome, `version` opcional com o starter-parent).

| Comando | Faz |
|---|---|
| mvn clean | Apaga `target` |
| mvn test | Compila + testa |
| mvn package | Gera o `.jar` em `target` |
| mvn install | package + instala no `.m2` |
| mvn spring-boot:run | Sobe a aplicação |

Sem Maven instalado: `.\mvnw.cmd spring-boot:run` (Maven Wrapper).
Mudou o pom.xml? → **Load Maven Changes** no IntelliJ.

## Spring Initializr (start.spring.io)
Maven · Java · Boot estável (sem SNAPSHOT/M) · Group `br.com.suaempresa` · Artifact `restaurante` · Jar · Java = **sua versão do JDK**.
Dependências: **Spring Web, Thymeleaf, Spring Data JPA, H2, MySQL Driver, DevTools** (todas já no pom.xml deste projeto).

## Estrutura
```
restaurante/
 ├── pom.xml
 ├── src/main/java/br/com/suaempresa/restaurante/RestauranteApplication.java  ← rode esta
 ├── src/main/resources/static/        (CSS, imagens, JS)
 ├── src/main/resources/templates/     (HTML Thymeleaf)
 ├── src/main/resources/application.properties
 └── src/test/java/                    (testes)
```

| Problema | Causa |
|---|---|
| Sem ícone do Maven | Abriu a pasta errada (abra a que tem o pom.xml) |
| Erro de versão do Java | `<java.version>` ≠ JDK instalado |
| main class not found | Rode o `...Application.java` |
| `package ... does not exist` | Falta dependência no pom ou não recarregou o Maven |

## Programa deste pacote
Projeto `restaurante` com a demonstração de IoC: `ProdutoRepository` (@Repository) é injetado no
`ProdutoService` (@Service) via `@Autowired`. Ao rodar, aparece **Salvando: Pizza** no console.
