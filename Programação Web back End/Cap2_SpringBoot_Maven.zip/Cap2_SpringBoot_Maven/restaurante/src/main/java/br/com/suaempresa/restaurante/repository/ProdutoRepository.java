package br.com.suaempresa.restaurante.repository;

import org.springframework.stereotype.Repository;

/*
 * Exemplo didático do Capítulo 2 (IoC).
 * @Repository registra a classe como Bean: o Spring cria o objeto sozinho.
 * (No Capítulo 4 ela vira uma interface que estende JpaRepository.)
 */
@Repository
public class ProdutoRepository {

	public void salvar(String produto) {
		System.out.println("Salvando: " + produto);
	}
}
