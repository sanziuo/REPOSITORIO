package br.com.suaempresa.restaurante;

import br.com.suaempresa.restaurante.service.ProdutoService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/*
 * CLASSE PRINCIPAL - é ela que você executa (botão ▷ ou Shift+F10).
 *
 * @SpringBootApplication = 3 anotações em uma:
 *  - @Configuration          : a classe pode declarar Beans (métodos @Bean)
 *  - @EnableAutoConfiguration: o Spring Boot se configura sozinho a partir do pom.xml
 *  - @ComponentScan          : varre ESTE pacote e os SUBPACOTES procurando
 *                              @Component, @Service, @Repository, @Controller
 */
@SpringBootApplication
public class RestauranteApplication {

	public static void main(String[] args) {
		// Liga o container Spring (IoC) e o servidor Tomcat embutido.
		SpringApplication.run(RestauranteApplication.class, args);
	}

	/*
	 * Demonstração de IoC/DI: roda logo depois que o Spring sobe.
	 * Repare que NÃO fazemos "new ProdutoService()": o Spring injeta o Bean pronto.
	 * Saída esperada no console: "Salvando: Pizza"
	 */
	@Bean
	CommandLineRunner demonstracaoIoC(ProdutoService service) {
		return args -> service.cadastrar("Pizza");
	}
}
