package br.com.suaempresa.restaurante.service;

import br.com.suaempresa.restaurante.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
 * @Service também registra a classe como Bean.
 *
 * SEM Spring (acoplamento forte):
 *     private ProdutoRepository repository = new ProdutoRepository();
 *
 * COM Spring (IoC + Injeção de Dependência):
 *     @Autowired private ProdutoRepository repository;
 *   -> o container procura um Bean ProdutoRepository e o encaixa aqui.
 */
@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository repository; // nenhum "new"!

	public void cadastrar(String produto) {
		repository.salvar(produto);
	}
}
