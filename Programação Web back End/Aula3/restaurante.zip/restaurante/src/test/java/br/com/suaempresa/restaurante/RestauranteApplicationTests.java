package br.com.suaempresa.restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
