# Capítulo 1 — Preparando o Ambiente de Desenvolvimento

## JDK, JRE e JVM  (JDK ⊃ JRE ⊃ JVM)
| Sigla | O que é |
|---|---|
| JVM | Executa o código Java (portabilidade) |
| JRE | JVM + bibliotecas → só **roda** programas |
| JDK | JRE + ferramentas (`javac`, depurador) → para **desenvolver** (é o que se instala) |

- **JAVA_HOME** → pasta do JDK (ex.: `C:\Program Files\Java\jdk-21`). Usada por Maven e outras ferramentas.
- **Path** → onde o terminal procura comandos; deve conter `%JAVA_HOME%\bin`.
- **LTS** = suporte de longo prazo (21, 25…) → recomendada.

## IntelliJ IDEA
| Elemento | Onde |
|---|---|
| Editor | centro |
| Gutter | margem esquerda (▷, breakpoints, erros) |
| Project | painel esquerdo |
| Terminal | painel inferior (`Alt+F12`) |
| Run | ▷ verde no topo |

| Atalho | Ação |
|---|---|
| Shift+F10 | Executar |
| Ctrl+Espaço | Autocompletar |
| Alt+Insert | Gerar getters/setters/construtores |
| Ctrl+Alt+L | Formatar |
| Shift Shift | Buscar tudo |
| Ctrl+B | Ir para a declaração |

## Git e GitHub
Git = histórico local · GitHub = histórico na nuvem.
Fluxo: **alterar → `git add .` → `git commit -m "msg"` → `git push`**

| Comando | Faz |
|---|---|
| git init | Cria repositório |
| git status | Mostra alterações |
| git add . | Prepara alterações |
| git commit -m | Grava no histórico |
| git log | Histórico |
| git push / pull | Envia / traz do GitHub |
| git clone url | Copia repositório remoto |

- `.gitignore`: o que o Git ignora (`.idea/`, `*.iml`, `target/`, `.env`).
- SSH: `ssh-keygen -t ed25519` → chave pública em GitHub › Settings › SSH and GPG keys.
- `Permission denied (publickey)` → chave não cadastrada ou remoto em HTTPS.

## Docker
| | Máquina Virtual | Container |
|---|---|---|
| Virtualiza | hardware + SO próprio | só processos (compartilha o kernel) |
| Tamanho | GB | MB |
| Inicialização | minutos | segundos |

- **Imagem** = molde · **Container** = instância rodando.
- Comandos: `docker images`, `docker ps`, `docker ps -a`, `docker stop/start/rm <nome>`.
- **WSL 2** = Linux dentro do Windows; o Docker precisa dele. Erro → `wsl --update` (admin).

## Checklist
`java -version` · `javac -version` · `git --version` · `git config --global --list` · `docker --version` · `docker run hello-world`

## Exercício de fixação
1. Criar no GitHub o repositório vazio **estudos-restaurante**, clonar, adicionar `README.md`, `add/commit/push` (veja `comandos.ps1`).
2. Abrir a pasta no IntelliJ e explorar Project e Terminal.
3. Rodar `docker run hello-world` 2x — **a 2ª é mais rápida porque a imagem já está em cache local** (não precisa baixar de novo; confira com `docker images`).
4. Criar o `.gitignore` (já incluso) e confirmar com `git status` que `.idea/` e `target/` somem da lista.
   Se `.idea/` já tinha sido commitada: `git rm -r --cached .idea` e novo commit.
