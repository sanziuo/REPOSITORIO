# ===== CAPÍTULO 1 - Roteiro de comandos (PowerShell) =====

# --- Checklist do ambiente ---
java -version
javac -version
git --version
git config --global --list
docker --version
docker run hello-world

# --- Configurar o Git (só uma vez) ---
git config --global user.name  "Seu Nome"
git config --global user.email "seu-email@exemplo.com"

# --- Chave SSH para o GitHub ---
ssh-keygen -t ed25519 -C "seu-email@exemplo.com"
Get-Content $HOME\.ssh\id_ed25519.pub   # copie e cole em GitHub > Settings > SSH and GPG keys

# --- Exercício: clonar, criar README, enviar ---
cd C:\Users\sanzi\Documents\Github
git clone git@github.com:SEU-USUARIO/estudos-restaurante.git
cd estudos-restaurante
# (copie para cá o README.md e o .gitignore deste pacote)
git status
git add .
git commit -m "Adiciona README e .gitignore"
git push

# --- Docker: rode duas vezes e compare o tempo ---
docker run hello-world
docker images
docker ps -a
